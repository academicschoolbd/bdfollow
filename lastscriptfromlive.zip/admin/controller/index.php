<?php
if (!defined('BASEPATH')) {
    die('Direct access to the script is not allowed');
}
if ($admin["access"]["admin_access"] != 1) {
    header("Location:" . site_url("admin"));
    exit();
}

// $clients fetch removed: dashboard view never reads $clients, the old
// "SELECT * FROM clients LIMIT 500" was wasted work on every page load.

// Use COUNT(*) — old version streamed every matching row over the wire.
$stmt = $conn->prepare(
    "SELECT COUNT(*) AS c FROM orders WHERE dripfeed='1' AND subscriptions_type='1' AND order_error != :error"
);
$stmt->execute(array("error" => "-"));
$failCount = (int) $stmt->fetch(PDO::FETCH_ASSOC)["c"];

$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM orders WHERE last_check = :date");
$stmt->execute(array("date" => date("Y-m-d")));
$todayCount = (int) $stmt->fetch(PDO::FETCH_ASSOC)["c"];

require admin_view('index');
