<?php
if(!defined('BASEPATH')) {
   die('Direct access to the script is not allowed');
}
if( $admin["access"]["services"] != 1  ){
    header("Location:".site_url("admin"));
    exit();
}
session_start();
if (route(2) && is_numeric(route(2))) :
    $page = route(2);
else :
    $page = 1;
endif;

$smmapi = new SMMApi();

if (route(2) == "ajax_services_update" && !$_POST) {
    $information = array(
        'type' => 'error',
        'message' => 'No data available, Please try again!',
    );

    $_SESSION["information"] = $information;

    Header("Location:" . site_url('admin/api-services'));
}

if (route(2) == "ajax_services_last" && (!$_SESSION["cat_data"] && !$_SESSION["multiple"])) {
    $information = array(
        'type' => 'error',
        'message' => 'No data available, Please try again!',
    );
    $_SESSION["information"] = $information;

    Header("Location:" . site_url('admin/api-services'));
}

if (!route(2)) :

    if (
        $_SESSION["provider"] || $_SESSION["cat_data"] || $_SESSION["provider_services"]
        || $_SESSION["profit"] || $_SESSION["information"] || $_SESSION["multiple"]
    ) {

        unset($_SESSION["provider"]);
        unset($_SESSION["cat_data"]);
        unset($_SESSION["profit"]);
        unset($_SESSION["information"]);
        unset($_SESSION["provider_services"]);
        unset($_SESSION["multiple"]);
    }

    $providers  = $conn->prepare("SELECT * FROM service_api ORDER BY id ASC");
    $providers->execute(array());
    $providers  = $providers->fetchAll(PDO::FETCH_ASSOC);


elseif (route(2) == "ajax_services_update" && $_POST) :


    $provider_id = $_POST['api_fetch_id'];

    $provider = $conn->prepare('SELECT * FROM service_api WHERE id=:id');
    $provider->execute(['id' => $provider_id]);
    $provider = $provider->fetch(PDO::FETCH_ASSOC);


if ($_POST && (empty($_POST['api_fetch_id']) ||  empty($provider))) :
$information = array(
            "type" => "danger",
            "message" => "Provider must be there to fetch services",
        );
   /* elseif ($_POST && (empty($_POST['profit']) || $_POST['profit'] < 0)) :
        $information = array(
            "type" => "danger",
            "message" => "Profit must be more than 0",
        );*/
    else :
        $information = array();
    endif;

    $_SESSION["information"] = $information;


    if ($information["type"] != "danger") {


        $categoriesData = $conn->prepare('SELECT * FROM categories WHERE category_deleted=:del ORDER BY category_line ');
        $categoriesData->execute(["del" => 0]);
        $categoriesData = $categoriesData->fetchAll(PDO::FETCH_ASSOC);


        if ($provider['api_type'] == 1) :
            $services = $smmapi->action(['key' => $provider['api_key'], 'action' => 'services'], $provider['api_url']);
        endif;

        $servicesCount = count($services);
        // if ($servicesCount > 100) {
        //     $disabled = "disabled";
        // }


        $_SESSION["provider"] = $provider;
        $_SESSION["profit"] = $_POST['profit'];
    } else {
        $services = json_encode(['error' => 'Something went wrong!']);
        Header("Location:" . site_url('admin/api-services'));
    }



elseif (route(2) == "ajax_services_add" && $_POST) :
 
    parse_str(json_decode($_POST["form_data"]), $postData);


    $checkBoxes = $postData['checkbox'];
    $category_ids = $postData['category_ids'];
    $category_name = $postData['category_name'];
    $old_category_name = $postData['old_category_name'];
    $status = $postData['status'];

    // Pre-compute the next category_line ONCE (was inside the loop before)
    $categoryLineRow = $conn->prepare("SELECT category_line FROM categories ORDER BY category_line DESC LIMIT 1");
    $categoryLineRow->execute(array());
    $categoryLineRow = $categoryLineRow->fetch(PDO::FETCH_ASSOC);
    $nextCategoryLine = empty($categoryLineRow["category_line"]) ? 0 : (int) $categoryLineRow["category_line"];

    // Fetch default language ONCE (was queried per new category before)
    $defaultLang = $conn->prepare("SELECT * FROM languages WHERE default_language=:default");
    $defaultLang->execute(array("default" => 1));
    $defaultLang = $defaultLang->fetch(PDO::FETCH_ASSOC);
    $defaultLangCode = $defaultLang["language_code"];

    $findCatByName = $conn->prepare("SELECT category_id FROM categories WHERE category_name=:name AND category_deleted=:del LIMIT 1");
    $insertCat = $conn->prepare("INSERT INTO categories SET category_name=:category_name, category_name_lang=:category_name_lang, category_line=:category_line, category_type=2, category_secret=2");

    $i = 0;
    $nextData = array();
    foreach ($checkBoxes as $check) {

        $cat_id = $category_ids[$check];

        if ($cat_id == 0) {
            // Auto-match by category name first; only insert if no existing category with same name.
            $findCatByName->execute(array("name" => $category_name[$check], "del" => 0));
            $existing = $findCatByName->fetch(PDO::FETCH_ASSOC);

            if (!empty($existing)) {
                $cat_id = $existing["category_id"];
                $category_ids[$check] = $cat_id;
            } else {
                $nextCategoryLine++;
                $MultiCatName = json_encode([$defaultLangCode => $category_name[$check]]);
                $insertCat->execute(array(
                    "category_name" => $category_name[$check],
                    "category_name_lang" => $MultiCatName,
                    "category_line" => $nextCategoryLine,
                ));
                $cat_id = $conn->lastInsertId();
                $i++;
            }
        }

        $nextData[] = array(
            "id" => $check,
            "category_id" => $cat_id,
            "api_category_name" => $old_category_name[$check],
        );
    }

    $information = array(
        'type' => 'success',
        'message' => $i . ' Categories inserted succesfully',
    );

    $_SESSION["cat_data"] = $nextData;
    $_SESSION["information"] = $information;

    Header("Location:" . site_url('admin/api-services/ajax_services_last'));

elseif (route(2) == "ajax_services_last") :

    // unset($_SESSION['multiple']);
    // p('done');



    if ($_SESSION['multiple']['status'] != 1) {
        $cat_data = $_SESSION["cat_data"];
        $profit = $_SESSION["profit"];


        $provider = $_SESSION["provider"];

        $countCatToAdd = count($cat_data);
        $dividingNumber = 50;
        if ($countCatToAdd > $dividingNumber) :
            $multiple = 1;
            $totalPages = ceil($countCatToAdd / $dividingNumber);
            $page = 1;
            $new_cat_divided_data =  array_chunk($cat_data, $dividingNumber);
            $multipleQuantity = array(
                'status' => $multiple,
                'totalPages' => $totalPages,
                'currentPage' => $page,
                'data' => $new_cat_divided_data,
            );
            $pageMessage = "Page " . $multipleQuantity['currentPage'] . " Out of " . $multipleQuantity['totalPages'] . " , Please wait the page to load all data properly!";
            $new_cat_divided_data = $new_cat_divided_data[$multipleQuantity['currentPage'] - 1];
            $multipleQuantity['currentPage']++;
            $_SESSION['multiple'] = $multipleQuantity;
        // unset($_SESSION['cat_data']);
        else :
            $new_cat_divided_data = $cat_data;
            $pageMessage = "";
        endif;
    } else {
        $profit = $_SESSION["profit"];
        $provider = $_SESSION["provider"];
        $multipleQuantity = $_SESSION['multiple'];

        if ($multipleQuantity['currentPage'] <= $multipleQuantity['totalPages']) :
            $new_cat_divided_data = $multipleQuantity['data'][$multipleQuantity['currentPage'] - 1];
            $pageMessage = "Page " . $multipleQuantity['currentPage'] . " Out of " . $multipleQuantity['totalPages'] . " , Please wait the page to load all data properly!";
            $multipleQuantity['currentPage']++;
            $multipleQuantity['currentPage'] > $multipleQuantity['totalPages'] ?  $multipleQuantity['status'] = 0 :  $multipleQuantity['status'] = 1;
            $_SESSION['multiple'] = $multipleQuantity;
        endif;
    }


    if (empty($_SESSION['provider_services'])) :
        if ($provider['api_type'] == 1) :
            $services = $smmapi->action(['key' => $provider['api_key'], 'action' => 'services'], $provider['api_url']);
            $_SESSION['provider_services'] = $services;
        endif;
    else :
        $services =  $_SESSION['provider_services'];
    endif;

    $getServicesByCategory = array();

    $servicesCount = 0;
    foreach ($new_cat_divided_data as $category) {



        $c_id = $category["category_id"];
        $servicesArray = array();

        $api_category_name = $category["api_category_name"];

        foreach ($services as $service) {

            if (urlencode($service->category) == urlencode($api_category_name)) {
                $servicesCount++;
                array_push($servicesArray, $service);
            }
        }

        $getServicesByCategory[$c_id] = $servicesArray;
    }
    // p(($getServicesByCategory));

    // Build a small lookup map (category_id => row) for the view.
    // Skipping the previous "SELECT * FROM services" entirely: rendering a per-row
    // <select> with every existing service was the main cause of slow page loads.
    // Existing services are now matched automatically by (provider, api_service)
    // in ajax_services_addNow below.
    $allCategories = $conn->prepare('SELECT category_id, category_name, category_type FROM categories WHERE category_deleted=:del ORDER BY category_line');
    $allCategories->execute(["del" => 0]);
    $allCategories = $allCategories->fetchAll(PDO::FETCH_ASSOC);
    $categoryNamesById = array();
    foreach ($allCategories as $__cat) {
        $categoryNamesById[$__cat["category_id"]] = $__cat["category_name"];
    }
    $allServices = array();



elseif (route(2) == "ajax_services_addNow") :


    $decodedString = json_decode($_POST["form_data"], true);
    $newArray = array();
    $loopCounter = 0;
    foreach ($decodedString as $key) {
        if ($loopCounter >= 3) {
            $keyName = $key['name'];
            $keyName = explode('[', $keyName);
            $keyIndex = explode(']', $keyName[1]);
            $keyName = $keyName[0];
            $keyIndex = $keyIndex[0];
            $newArray[$keyName][$keyIndex] = $key['value'];
        }
        $loopCounter++;
    }
    $postData  = $newArray;
    $postData['service_profit_percentage'] = ($decodedString[0]['value']);
    $postData['import']                    = ($decodedString[1]['value']);
    $postData['status']                    = ($decodedString[2]['value']);

    foreach ($postData as $key => $value) {
        $$key = $value;
    }

    // ---- Speed-up: load provider data ONCE outside the loop ----
    // Every row in the submitted form has the same service_provider_array value,
    // so we previously ran "SELECT * FROM service_api WHERE id=..." once per row.
    $providerDataCache = array();
    $providerStmt = $conn->prepare("SELECT * FROM service_api WHERE id=:id");
    // Pre-compute max(service_line) once and increment in-memory per insert.
    $serviceLineRow = $conn->prepare("SELECT service_line FROM services ORDER BY service_line DESC LIMIT 1");
    $serviceLineRow->execute(array());
    $serviceLineRow = $serviceLineRow->fetch(PDO::FETCH_ASSOC);
    $nextServiceLine = empty($serviceLineRow["service_line"]) ? 0 : (int) $serviceLineRow["service_line"];

    // Auto-update: if a service_id of 0 was submitted but a service with the same
    // (provider, api_service) already exists, update it instead of inserting a duplicate.
    $findExistingService = $conn->prepare("SELECT service_id FROM services WHERE service_api=:api AND api_service=:api_service AND service_deleted='0' LIMIT 1");

    $insertSvc = $conn->prepare("INSERT INTO services SET service_api=:api,
        api_service=:api_service, api_detail=:detail, category_id=:category,
        service_line=:line, service_type=:type, service_package=:package,
        service_name=:name, service_description=:desc, service_price=:price,
        service_min=:min, service_max=:max, show_refill=:refill, price_profit=:price_profit,
        name_lang=:multiName, description_lang=:multi");
    $updateSvc = $conn->prepare("UPDATE services SET service_api=:api,
        api_service=:api_service, api_detail=:detail, category_id=:category,
        service_type=:type, service_package=:package,
        service_name=:name, service_description=:desc, service_price=:price,
        service_min=:min, service_max=:max, show_refill=:refill, price_profit=:price_profit,
        name_lang=:multiName, description_lang=:multi
        WHERE service_id=:service_id");

    $service_profit_percentage = $postData["service_profit_percentage"];
    $i = 0;

    foreach ($checkbox as $cKey => $Cvalue) {

        $cat_id            = $category_ids_array[$cKey];
        $service_id        = $our_services_ids_array[$cKey];
        $service_name      = mb_convert_encoding($service_name_array[$cKey], 'UTF-8', 'UTF-8');
        $service_api_id    = $api_service_id_array[$cKey];
        $service_price     = $prices_array[$cKey];
        $service_api_price = $service_api_prices[$cKey];
        $service_min       = $min_array[$cKey];
        $service_max       = $max_array[$cKey];
        $service_desc      = $description_array[$cKey];
        $service_type      = $service_type_array[$cKey];
        $service_refill    = empty($service_refill_array[$cKey]) ? 0 : $service_refill_array[$cKey];
        $provider_id       = $service_provider_array[$cKey];
        $package           = serviceTypeGetList($service_type);

        if (!isset($providerDataCache[$provider_id])) {
            $providerStmt->execute(array("id" => $provider_id));
            $providerDataCache[$provider_id] = $providerStmt->fetch(PDO::FETCH_ASSOC);
        }
        $providerData = $providerDataCache[$provider_id];

        $detail = array(
            "min"      => $service_min,
            "max"      => $service_max,
            "rate"     => $service_api_price,
            "currency" => $providerData["currency"],
        );

        // If no explicit service_id was submitted, try to match an existing
        // service by (provider, api_service) so we update instead of duplicating.
        if ($service_id == 0) {
            $findExistingService->execute(array(
                "api"         => $provider_id,
                "api_service" => $service_api_id,
            ));
            $existingSvc = $findExistingService->fetch(PDO::FETCH_ASSOC);
            if (!empty($existingSvc)) {
                $service_id = $existingSvc["service_id"];
            }
        }

        $multiName = json_encode(['en' => $service_name_array[$cKey]]);
        $multiDesc = json_encode(['en' => $service_desc]);
        $service_refill_str = ($service_refill == 1) ? "true" : "false";

        if ($service_id == 0) {
            // Insert new service
            $nextServiceLine++;
            $insertSvc->execute(array(
                "api"           => $provider_id,
                "api_service"   => $service_api_id,
                "detail"        => json_encode($detail),
                "category"      => $cat_id,
                "line"          => $nextServiceLine,
                "type"          => 2,
                "package"       => $package,
                "name"          => $service_name,
                "desc"          => $service_desc,
                "price"         => $service_price,
                "min"           => $service_min,
                "max"           => $service_max,
                "refill"        => $service_refill_str,
                "price_profit"  => $service_profit_percentage,
                "multiName"     => $multiName,
                "multi"         => $multiDesc,
            ));
        } else {
            // Update existing service
            $ok = $updateSvc->execute(array(
                "api"           => $provider_id,
                "api_service"   => $service_api_id,
                "detail"        => json_encode($detail),
                "category"      => $cat_id,
                "type"          => 2,
                "package"       => $package,
                "name"          => $service_name,
                "desc"          => $service_desc,
                "price"         => $service_price,
                "min"           => $service_min,
                "max"           => $service_max,
                "refill"        => $service_refill_str,
                "price_profit"  => $service_profit_percentage,
                "service_id"    => $service_id,
                "multiName"     => $multiName,
                "multi"         => $multiDesc,
            ));
            if ($ok && function_exists('insertAdminLog')) {
                insertAdminLog("Service Updated Through API", "service id => " . $service_id);
            }
        }
        $i++;
    }

    if (!$_SESSION["multiple"]["status"]) :
        unset($_SESSION["provider"]);
        unset($_SESSION["cat_data"]);
        unset($_SESSION["profit"]);
        unset($_SESSION["information"]);
        unset($_SESSION["provider_services"]);
        unset($_SESSION["multiple"]);
        $postData = array();
        header("Location:" . site_url("admin/services"));
    else :
        $_POST = array();
        $postData = array();
        header("Location:" . site_url("admin/api-services/ajax_services_last"));
    endif;






elseif (route(2) == "ajax_services_auto") :

    // ---------------- Auto-Import All ----------------
    // Flush any buffered output (PHP / index.php often have ob_start active);
    // we want the response to be pure JSON.
    while (ob_get_level() > 0) { ob_end_clean(); }

    // Fetches services from the chosen provider and imports them WITHOUT the
    // manual category/service selection screens.
    //  * Categories: found by name (or created if missing).
    //  * Services:   updated when (provider, api_service) already exists,
    //                inserted otherwise.
    // Runs in chunks so a single request stays under PHP's max_execution_time.
    //
    // POST input:  api_fetch_id (int), profit (int), offset (int, default 0),
    //              chunk_size (int, default 50)
    // POST output: JSON { ok, done, total, processed, inserted_categories,
    //                     inserted_services, updated_services, message,
    //                     next_offset }

    header('Content-Type: application/json; charset=utf-8');

    if (empty($_POST)) {
        echo json_encode(["ok" => false, "message" => "No data"]);
        exit;
    }

    $provider_id = (int) $_POST['api_fetch_id'];
    $profit      = is_numeric($_POST['profit']) ? (float) $_POST['profit'] : 0;
    $offset      = isset($_POST['offset']) ? (int) $_POST['offset'] : 0;
    $chunk_size  = isset($_POST['chunk_size']) ? max(1, min(200, (int) $_POST['chunk_size'])) : 50;

    $provider = $conn->prepare("SELECT * FROM service_api WHERE id=:id");
    $provider->execute(array("id" => $provider_id));
    $provider = $provider->fetch(PDO::FETCH_ASSOC);
    if (empty($provider)) {
        echo json_encode(["ok" => false, "message" => "Provider not found"]);
        exit;
    }

    // Cache the full service list from the provider in the session so we don't
    // re-fetch it on every chunk request.
    if (empty($_SESSION["auto_import"]) || $_SESSION["auto_import"]["provider_id"] != $provider_id) {
        if ($provider['api_type'] == 1) {
            $services = $smmapi->action(['key' => $provider['api_key'], 'action' => 'services'], $provider['api_url']);
        } else {
            $services = false;
        }
        if (!is_array($services) || empty($services)) {
            echo json_encode(["ok" => false, "message" => "Provider returned no services"]);
            exit;
        }
        // Store as a plain array of arrays to keep the session small and avoid
        // any object-vs-array surprises across requests.
        $servicesPlain = array();
        foreach ($services as $sv) {
            $servicesPlain[] = array(
                "category"    => isset($sv->category)    ? $sv->category    : '',
                "service"     => isset($sv->service)     ? $sv->service     : '',
                "name"        => isset($sv->name)        ? $sv->name        : '',
                "type"        => isset($sv->type)        ? $sv->type        : 'Default',
                "rate"        => isset($sv->rate)        ? $sv->rate        : 0,
                "min"         => isset($sv->min)         ? $sv->min         : 0,
                "max"         => isset($sv->max)         ? $sv->max         : 0,
                "description" => isset($sv->description) ? $sv->description : (isset($sv->desc) ? $sv->desc : ''),
                "refill"      => isset($sv->refill)      ? $sv->refill      : 0,
            );
        }
        $_SESSION["auto_import"] = array(
            "provider_id"          => $provider_id,
            "profit"               => $profit,
            "services"             => $servicesPlain,
            "total"                => count($servicesPlain),
            "inserted_categories"  => 0,
            "inserted_services"    => 0,
            "updated_services"     => 0,
            "started_at"           => time(),
        );
    }

    $state    = $_SESSION["auto_import"];
    $services = $state["services"];
    $total    = $state["total"];

    if ($offset >= $total) {
        $summary = "Done. " . $state["inserted_services"] . " services inserted, "
                 . $state["updated_services"] . " updated, "
                 . $state["inserted_categories"] . " new categories.";
        unset($_SESSION["auto_import"]);
        echo json_encode([
            "ok"                  => true,
            "done"                => true,
            "total"               => $total,
            "processed"           => $total,
            "inserted_categories" => $state["inserted_categories"],
            "inserted_services"   => $state["inserted_services"],
            "updated_services"    => $state["updated_services"],
            "message"             => $summary,
            "next_offset"         => $total,
        ]);
        exit;
    }

    // Prepare lookup helpers once per chunk.
    $findCatByName = $conn->prepare("SELECT category_id FROM categories WHERE category_name=:name AND category_deleted=:del LIMIT 1");
    $insertCat = $conn->prepare("INSERT INTO categories SET category_name=:category_name, category_name_lang=:category_name_lang, category_line=:category_line, category_type=2, category_secret=2");

    $categoryLineRow = $conn->prepare("SELECT category_line FROM categories ORDER BY category_line DESC LIMIT 1");
    $categoryLineRow->execute(array());
    $categoryLineRow = $categoryLineRow->fetch(PDO::FETCH_ASSOC);
    $nextCategoryLine = empty($categoryLineRow["category_line"]) ? 0 : (int) $categoryLineRow["category_line"];

    $serviceLineRow = $conn->prepare("SELECT service_line FROM services ORDER BY service_line DESC LIMIT 1");
    $serviceLineRow->execute(array());
    $serviceLineRow = $serviceLineRow->fetch(PDO::FETCH_ASSOC);
    $nextServiceLine = empty($serviceLineRow["service_line"]) ? 0 : (int) $serviceLineRow["service_line"];

    $defaultLang = $conn->prepare("SELECT * FROM languages WHERE default_language=:default");
    $defaultLang->execute(array("default" => 1));
    $defaultLang = $defaultLang->fetch(PDO::FETCH_ASSOC);
    $defaultLangCode = $defaultLang["language_code"];

    $findExistingService = $conn->prepare("SELECT service_id FROM services WHERE service_api=:api AND api_service=:api_service AND service_deleted='0' LIMIT 1");

    $insertSvc = $conn->prepare("INSERT INTO services SET service_api=:api,
        api_service=:api_service, api_detail=:detail, category_id=:category,
        service_line=:line, service_type=:type, service_package=:package,
        service_name=:name, service_description=:desc, service_price=:price,
        service_min=:min, service_max=:max, show_refill=:refill, price_profit=:price_profit,
        name_lang=:multiName, description_lang=:multi");
    $updateSvc = $conn->prepare("UPDATE services SET service_api=:api,
        api_service=:api_service, api_detail=:detail, category_id=:category,
        service_type=:type, service_package=:package,
        service_name=:name, service_description=:desc, service_price=:price,
        service_min=:min, service_max=:max, show_refill=:refill, price_profit=:price_profit,
        name_lang=:multiName, description_lang=:multi
        WHERE service_id=:service_id");

    $end = min($offset + $chunk_size, $total);
    $providerCurrency  = $provider["currency"];
    $siteBaseCurrency  = $settings["site_base_currency"];
    $currenciesArray   = get_currencies_array("all");
    $categoryIdCache   = array();

    for ($idx = $offset; $idx < $end; $idx++) {
        $sv = $services[$idx];

        // ---- category: find by name or create ----
        $catName = $sv["category"];
        if ($catName === '') {
            $catName = "Uncategorized";
        }
        if (isset($categoryIdCache[$catName])) {
            $cat_id = $categoryIdCache[$catName];
        } else {
            $findCatByName->execute(array("name" => $catName, "del" => 0));
            $existing = $findCatByName->fetch(PDO::FETCH_ASSOC);
            if (!empty($existing)) {
                $cat_id = $existing["category_id"];
            } else {
                $nextCategoryLine++;
                $insertCat->execute(array(
                    "category_name"      => $catName,
                    "category_name_lang" => json_encode([$defaultLangCode => $catName]),
                    "category_line"      => $nextCategoryLine,
                ));
                $cat_id = $conn->lastInsertId();
                $state["inserted_categories"]++;
            }
            $categoryIdCache[$catName] = $cat_id;
        }

        // ---- price (provider rate -> site currency + profit %) ----
        $rate            = $sv["rate"];
        $servicePriceSite = from_to($currenciesArray, $providerCurrency, $siteBaseCurrency, $rate);
        $finalPrice       = $servicePriceSite + (($profit / 100) * $servicePriceSite);

        $detail = array(
            "min"      => $sv["min"],
            "max"      => $sv["max"],
            "rate"     => $rate,
            "currency" => $providerCurrency,
        );
        $service_name      = mb_convert_encoding($sv["name"], 'UTF-8', 'UTF-8');
        $service_api_id    = $sv["service"];
        $service_desc      = $sv["description"];
        $service_refill_str = ($sv["refill"] == 1) ? "true" : "false";
        $package           = serviceTypeGetList($sv["type"]);
        $multiName         = json_encode(['en' => $sv["name"]]);
        $multiDesc         = json_encode(['en' => $service_desc]);

        // ---- service: update if existing (provider, api_service), else insert ----
        $findExistingService->execute(array(
            "api"         => $provider_id,
            "api_service" => $service_api_id,
        ));
        $existingSvc = $findExistingService->fetch(PDO::FETCH_ASSOC);

        if (!empty($existingSvc)) {
            $updateSvc->execute(array(
                "api"           => $provider_id,
                "api_service"   => $service_api_id,
                "detail"        => json_encode($detail),
                "category"      => $cat_id,
                "type"          => 2,
                "package"       => $package,
                "name"          => $service_name,
                "desc"          => $service_desc,
                "price"         => $finalPrice,
                "min"           => $sv["min"],
                "max"           => $sv["max"],
                "refill"        => $service_refill_str,
                "price_profit"  => $profit,
                "service_id"    => $existingSvc["service_id"],
                "multiName"     => $multiName,
                "multi"         => $multiDesc,
            ));
            $state["updated_services"]++;
        } else {
            $nextServiceLine++;
            $insertSvc->execute(array(
                "api"           => $provider_id,
                "api_service"   => $service_api_id,
                "detail"        => json_encode($detail),
                "category"      => $cat_id,
                "line"          => $nextServiceLine,
                "type"          => 2,
                "package"       => $package,
                "name"          => $service_name,
                "desc"          => $service_desc,
                "price"         => $finalPrice,
                "min"           => $sv["min"],
                "max"           => $sv["max"],
                "refill"        => $service_refill_str,
                "price_profit"  => $profit,
                "multiName"     => $multiName,
                "multi"         => $multiDesc,
            ));
            $state["inserted_services"]++;
        }
    }

    $_SESSION["auto_import"] = $state;

    $done = ($end >= $total);
    $msg  = $done
        ? ("Done. " . $state["inserted_services"] . " services inserted, "
           . $state["updated_services"] . " updated, "
           . $state["inserted_categories"] . " new categories.")
        : ("Imported " . $end . " of " . $total . " ...");
    if ($done) {
        unset($_SESSION["auto_import"]);
    }
    echo json_encode([
        "ok"                  => true,
        "done"                => $done,
        "total"               => $total,
        "processed"           => $end,
        "inserted_categories" => $state["inserted_categories"],
        "inserted_services"   => $state["inserted_services"],
        "updated_services"    => $state["updated_services"],
        "message"             => $msg,
        "next_offset"         => $end,
    ]);
    exit;

endif;



require admin_view('api-services');