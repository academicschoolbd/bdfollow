<?php include 'header.php'; ?>

<?php
// === Dashboard data (1 chart query each instead of 12) =====================
$year = (int) (isset($_GET["year"]) ? $_GET["year"] : date("Y"));

$months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
$grossProfits = array_fill(0, 12, 0);
$netProfits   = array_fill(0, 12, 0);

// Single GROUP BY query for gross profit per month — replaces 12 queries.
$stmt = $conn->prepare(
    "SELECT MONTH(order_create) AS m,
            COALESCE(SUM(order_charge),0) AS gross,
            COALESCE(SUM(order_profit),0) AS profit
     FROM orders
     WHERE YEAR(order_create) = :y
       AND dripfeed = '1'
       AND subscriptions_type = '1'
     GROUP BY MONTH(order_create)"
);
$stmt->execute(array("y" => $year));
while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $i = ((int) $r["m"]) - 1;
    if ($i >= 0 && $i < 12) {
        $grossProfits[$i] = (float) $r["gross"];
        // "Net" in the original code = gross - profit (markup not from API).
        $netProfits[$i]   = (float) $r["gross"] - (float) $r["profit"];
    }
}

// === Card stats ============================================================
$totalUsers       = countRow(["table" => "clients"]);
$totalOrders      = countRow(["table" => "orders"]);
$refilling        = countRow(["table" => "tasks"]);
$unreadTickets    = countRow(["table" => "tickets",          "where" => ["client_new"        => 2]]);
$receivedPayments = countRow(["table" => "payments",         "where" => ["payment_status"    => 3]]);
$totalCategories  = countRow(["table" => "categories",       "where" => ["category_deleted"  => 0]]);
$totalServices    = countRow(["table" => "services",         "where" => ["service_deleted"   => 0]]);
$totalStaff       = countRow(["table" => "admin",            "where" => ["admin_type"        => 2]]);
$panelTotalOrders = $settings["panel_orders"] ?? 0;
$totalCurrencies  = countRow(["table" => "currencies",       "where" => ["is_enable"         => 1]]);
$totalProviders   = countRow(["table" => "service_api"]);
$totalBroadcasts  = countRow(["table" => "notifications_popup", "where" => ["status"          => 1]]);

$cards = [
    ["label" => "Total Users",                 "value" => $totalUsers,         "icon" => "fa-users",            "link" => "/admin/clients",            "tone" => "indigo"],
    ["label" => "Total Orders",                "value" => $totalOrders,        "icon" => "fa-shopping-bag",     "link" => "/admin/orders",             "tone" => "violet"],
    ["label" => "Refilling Orders",            "value" => $refilling,          "icon" => "fa-sync-alt",         "link" => "/admin/tasks",              "tone" => "amber"],
    ["label" => "Unread Tickets",              "value" => $unreadTickets,      "icon" => "fa-headset",          "link" => "/admin/tickets",            "tone" => "rose"],
    ["label" => "Received Payments",           "value" => $receivedPayments,   "icon" => "fa-credit-card",      "link" => "/admin/fund-add-history",   "tone" => "emerald"],
    ["label" => "Total Categories",            "value" => $totalCategories,    "icon" => "fa-th-large",         "link" => "/admin/services",           "tone" => "sky"],
    ["label" => "Total Services",              "value" => $totalServices,      "icon" => "fa-list",             "link" => "/admin/services",           "tone" => "indigo"],
    ["label" => "Total Staff",                 "value" => $totalStaff,         "icon" => "fa-user-shield",      "link" => "/admin/manager",            "tone" => "slate"],
    ["label" => "Total Orders (with fakes)",   "value" => $panelTotalOrders,   "icon" => "fa-chart-line",       "link" => "/admin/settings/site_count","tone" => "violet"],
    ["label" => "Total Currencies",            "value" => $totalCurrencies,    "icon" => "fa-coins",            "link" => "/admin/settings/site_count","tone" => "amber"],
    ["label" => "Total Providers",             "value" => $totalProviders,     "icon" => "fa-plug",             "link" => "/admin/settings/providers", "tone" => "emerald"],
    ["label" => "Active Broadcasts",           "value" => $totalBroadcasts,    "icon" => "fa-bullhorn",         "link" => "/admin/broadcasts",         "tone" => "rose"],
];
?>

<style>
/* Admin dashboard cards — modern look, scoped to the dashboard page only */
.adm-dash{padding:18px 20px 0;}
.adm-dash__title{font:600 22px/1.2 'Inter','Segoe UI',system-ui,sans-serif;color:#0f172a;margin:0 0 6px}
.adm-dash__subtitle{font:400 14px/1.5 'Inter','Segoe UI',system-ui,sans-serif;color:#64748b;margin:0 0 18px}
.adm-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;margin-bottom:22px}
@media (max-width: 1199px){.adm-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width: 991px){.adm-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width: 575px){.adm-grid{grid-template-columns:1fr}}

.adm-stat{
    display:flex;align-items:center;gap:14px;
    background:#fff;border:1px solid #e6e8f0;border-radius:14px;padding:16px 18px;
    box-shadow:0 1px 2px rgba(15,23,42,.04);
    transition:transform .18s ease, box-shadow .18s ease, border-color .18s ease;
    text-decoration:none;color:inherit;
}
.adm-stat:hover{transform:translateY(-1px);box-shadow:0 10px 24px rgba(15,23,42,.08);border-color:#d6d8e6;text-decoration:none}
.adm-stat__icon{
    width:48px;height:48px;flex:0 0 48px;border-radius:12px;
    display:inline-flex;align-items:center;justify-content:center;
    font-size:20px;color:#fff;
}
.adm-stat__body{display:flex;flex-direction:column;min-width:0;flex:1}
.adm-stat__value{font:700 22px/1.1 'Inter','Segoe UI',system-ui,sans-serif;color:#0f172a;letter-spacing:-.01em}
.adm-stat__label{font:500 12px/1.4 'Inter','Segoe UI',system-ui,sans-serif;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-top:4px}
.adm-stat__arrow{color:#cbd5e1;font-size:13px}
.adm-stat:hover .adm-stat__arrow{color:#6e44ff}

.adm-stat--indigo  .adm-stat__icon{background:#6366f1}
.adm-stat--violet  .adm-stat__icon{background:#6e44ff}
.adm-stat--emerald .adm-stat__icon{background:#10b981}
.adm-stat--amber   .adm-stat__icon{background:#f59e0b}
.adm-stat--rose    .adm-stat__icon{background:#ef4444}
.adm-stat--sky     .adm-stat__icon{background:#0ea5e9}
.adm-stat--slate   .adm-stat__icon{background:#475569}

.adm-chart-card{
    background:#fff;border:1px solid #e6e8f0;border-radius:14px;padding:18px 20px;
    box-shadow:0 1px 2px rgba(15,23,42,.04);margin-bottom:18px;
}
.adm-chart-card__head{display:flex;align-items:baseline;justify-content:space-between;margin-bottom:10px;gap:12px;flex-wrap:wrap}
.adm-chart-card__title{font:600 16px/1.2 'Inter','Segoe UI',system-ui,sans-serif;color:#0f172a;margin:0}
.adm-chart-card__sub{font:400 13px/1.4 'Inter','Segoe UI',system-ui,sans-serif;color:#64748b;margin:2px 0 0}
.adm-chart-card__year{font:500 13px/1.4 'Inter','Segoe UI',system-ui,sans-serif;color:#64748b}
.adm-chart-canvas{position:relative;height:320px;width:100%}

body.dark-mode .adm-stat,
body.dark-mode .adm-chart-card{background:#1f2937;border-color:#374151;color:#e5e7eb}
body.dark-mode .adm-stat__value,
body.dark-mode .adm-dash__title,
body.dark-mode .adm-chart-card__title{color:#f8fafc}
body.dark-mode .adm-stat__label,
body.dark-mode .adm-dash__subtitle,
body.dark-mode .adm-chart-card__sub,
body.dark-mode .adm-chart-card__year{color:#9ca3af}
</style>

<div class="adm-dash">
    <h2 class="adm-dash__title">Dashboard</h2>
    <p class="adm-dash__subtitle">An overview of your panel — users, orders, revenue and activity at a glance.</p>

    <div class="adm-grid">
    <?php foreach ($cards as $c): ?>
        <a href="<?= $c["link"] ?>" class="adm-stat adm-stat--<?= $c["tone"] ?>">
            <span class="adm-stat__icon"><i class="fas <?= $c["icon"] ?>"></i></span>
            <span class="adm-stat__body">
                <span class="adm-stat__value"><?= $c["value"] ?></span>
                <span class="adm-stat__label"><?= $c["label"] ?></span>
            </span>
            <span class="adm-stat__arrow"><i class="fas fa-arrow-right"></i></span>
        </a>
    <?php endforeach; ?>
    </div>

    <div class="adm-chart-card">
        <div class="adm-chart-card__head">
            <div>
                <h3 class="adm-chart-card__title">Monthly profit</h3>
                <p class="adm-chart-card__sub">Gross and net profit by month</p>
            </div>
            <span class="adm-chart-card__year"><i class="far fa-calendar-alt"></i> <?= $year ?></span>
        </div>
        <div class="adm-chart-canvas"><canvas id="reportChart"></canvas></div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
(function(){
    var ctx = document.getElementById('reportChart');
    if (!ctx) return;
    new Chart(ctx.getContext('2d'), {
        type: 'bar',
        data: {
            labels: <?= json_encode($months) ?>,
            datasets: [{
                label: 'Gross profit',
                backgroundColor: 'rgba(110, 68, 255, 0.85)',
                borderColor: 'rgba(110, 68, 255, 1)',
                borderRadius: 6,
                borderWidth: 0,
                data: <?= json_encode($grossProfits) ?>
            }, {
                label: 'Net profit',
                backgroundColor: 'rgba(16, 185, 129, 0.85)',
                borderColor: 'rgba(16, 185, 129, 1)',
                borderRadius: 6,
                borderWidth: 0,
                data: <?= json_encode($netProfits) ?>
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { boxWidth: 12, font: { family: 'Inter, sans-serif', size: 12 } } }
            },
            scales: {
                x: { grid: { display: false }, ticks: { font: { family: 'Inter, sans-serif' } } },
                y: { beginAtZero: true, grid: { color: 'rgba(15,23,42,.06)' }, ticks: { font: { family: 'Inter, sans-serif' } } }
            }
        }
    });
})();
</script>

<div class="modal modal-center fade" id="confirmChange" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static">
   <div class="modal-dialog modal-dialog-center" role="document">
      <div class="modal-content">
         <div class="modal-body text-center">
            <h4>Are you sure you want to proceed ?</h4>
            <div align="center">
               <a class="btn btn-primary" href="" id="confirmYes">Yes</a>
               <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="modal fade" id="modalDiv" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg" role="document">
     <div class="modal-content">
       <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
         <h4 class="modal-title" id="modalTitle"></h4>
       </div>
       <div id="modalContent"></div>
     </div>
   </div>
</div>

<?php include 'footer.php'; ?>
