<?php 
// List of cron files to run
$cronFiles = [
    'autolike.php',
    'autoreply.php',
    'average.php',
    'dripfeed.php',
    'orders.php',
    'payments.php',
    'refill.php',
    'bot.php',
    'seller-sync.php',
    // Add more cron files as needed
];

foreach ($cronFiles as $cronFile) {
    if (file_exists($cronFile)) {
        echo "Running $cronFile in the background...\n";
        
        // Execute the cron file in the background
        exec("php $cronFile > /dev/null 2>&1 &");

        echo "$cronFile is running in the background.\n";
    } else {
        echo "File $cronFile does not exist.\n";
    }
}
?>
