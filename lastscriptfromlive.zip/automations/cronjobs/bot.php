<?php
// Database configuration
$servername = "localhost";
$username = "u406245370_rock";
$password = "L?0LJB9m";
$dbname = "u406245370_rock";

// Telegram Bot configuration
$telegramBotToken = "7007403703:AAHYAP4-hWYkFzNGr9rRVfmbSZgG184_9ug";
$chatId = "6182576695";
$telegramApiUrl = "https://api.telegram.org/bot$telegramBotToken/sendMessage";

// Create a new PDO instance
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Query to find failed orders
    $stmt = $conn->prepare("SELECT order_id FROM orders WHERE order_status = 'Pending'");
    $stmt->execute();
    $failedOrders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Prepare the message to send
    $message = "Failed Orders:\n";
    if (empty($failedOrders)) {
        $message .= "No failed orders at the moment.";
    } else {
        foreach ($failedOrders as $order) {
            $message .= "Order ID: " . $order['order_id'] . "\n";
        }
    }

    // Send message to Telegram
    $postData = [
        'chat_id' => $chatId,
        'text' => $message
    ];
    $ch = curl_init($telegramApiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    $response = curl_exec($ch);
    curl_close($ch);

    // Optional: Log the response for debugging
    // file_put_contents('telegram_response.log', $response . "\n", FILE_APPEND);

} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

// Close the database connection
$conn = null;
?>
