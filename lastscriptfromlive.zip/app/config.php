<?php
define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://bdfollow.com' );
define('STYLESHEETS_URL', '//bdfollow.com' );
date_default_timezone_set('Asia/Dhaka');

/* 
 ini_set("display_errors","1");
error_reporting(E_ERROR);  */  

error_reporting(0);
return [
  'db' => [
    'name'    =>  'zgruhjabaz_bdfollow' ,
    'host'    =>  'localhost',
    'user'    =>  'zgruhjabaz_bdfollow' ,
    'pass'    =>  'zgruhjabaz_bdfollow' ,
    'charset' =>  'utf8mb4'
  ]
];

?>